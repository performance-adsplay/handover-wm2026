# Central de handover · Webmotors

Site estático, sem build. Publique a pasta inteira.

- `index.html`: central com todos os módulos, busca, pendências e checklist
- `docs/`: os 7 documentos avulsos, ligados a partir da central

Vercel: importe o repositório, framework "Other", sem comando de build, output na raiz.
